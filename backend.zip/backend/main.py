from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse
import os

app = FastAPI()

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    contents = await file.read()

    # Save file locally (optional)
    filepath = os.path.join("uploads", file.filename)
    os.makedirs("uploads", exist_ok=True)
    with open(filepath, "wb") as f:
        f.write(contents)

    # 🔹 Here is where you’d pass it to your ML model
    result = {
        "filename": file.filename,
        "status": "processed",
        "message": "File received successfully"
    }
    return JSONResponse(content=result)

# Run with: uvicorn main:app --reload --host 0.0.0.0 --port 5000
